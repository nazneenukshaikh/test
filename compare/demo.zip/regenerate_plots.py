"""
Standalone regenerator for the metric plots.

    python regenerate_plots.py            # writes ./metric_plots/*.png

Every shape, story and anomaly position below is a one-line edit.
Needs only numpy + matplotlib.
"""
import os, re, numpy as np, matplotlib
matplotlib.use('Agg')
"""One plot per metric from Metrics - Metrics.csv, each with a different time-series shape."""
import numpy as np, matplotlib.pyplot as plt, matplotlib.ticker as mticker

rng = np.random.default_rng(3)
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({'figure.dpi':140,'font.size':9,'axes.titlesize':10.5,
    'axes.titleweight':'bold','axes.labelsize':8.5,'xtick.labelsize':8,
    'ytick.labelsize':8,'legend.fontsize':7.5,'axes.edgecolor':'#cfcfcf'})
INK,BAND,ALERT,MUTED,INK2,BAND2 = '#1f2a44','#4C72B0','#C44E52','#8a94a6','#55704f','#55A868'

T, T0, N, WARM = 520, 440, 60, 12
t  = np.arange(T); td = t - T0
EX = slice(T0, T0+N); x = np.arange(1, N+1)

# ---------------- pattern generators ---------------------------------- #
def wob(phi=.35, s=1.0, swing=.55, per=26, ph=0.):
    lv = s*(1 + swing*np.sin(2*np.pi*(t/per + ph)))
    e = rng.normal(0,1,T)*lv; o = np.zeros(T)
    for i in range(1,T): o[i] = phi*o[i-1] + e[i]
    return o
def wave(per, comps):  return sum(a*np.sin(2*np.pi*t/(per/h)+p) for h,a,p in comps)
def rwalk(s):          w = np.cumsum(rng.normal(0,s,T)); return w - w[T0]
def ou(mu, theta, s):
    o = np.full(T, mu)
    for i in range(1,T): o[i] = o[i-1] + theta*(mu-o[i-1]) + rng.normal(0,s)
    return o
def bimodal(a, b, p=.30):
    st = np.zeros(T); cur = 0
    for i in range(T):
        if rng.random() < p: cur = 1-cur
        st[i] = cur
    return np.where(st==0, a, b)
def sawtooth(per, lo, hi, jit=.04):
    ph = (t % per)/per
    return lo + (hi-lo)*ph + rng.normal(0,(hi-lo)*jit,T)
def pulses(per, base, peak, w=1.6):
    ph = ((t % per) - per//2)
    return base + peak*np.exp(-(ph**2)/(2*w**2))
def stair(levels):                       # [(start_index, value), ...]
    o = np.zeros(T)
    for s_,v_ in levels: o[s_:] = v_
    return o

# ---------------- band engine ----------------------------------------- #
def engine(y, alpha=.20, beta=None, gamma=None, P=12, k=3.2, log=False,
           a1=.16, a2=.28, floor=None, vmin=0.0):
    z = np.log(np.maximum(y,1e-9)) if log else np.asarray(y,float)
    ti = np.arange(WARM); b,a = np.polyfit(ti, z[:WARM], 1)
    S = np.zeros(P) if gamma is not None else None
    l, tr = a + b*(WARM-1), (b if beta is not None else 0.)
    v1 = v2 = vL = max(np.var(z[:WARM]-(a+b*ti), ddof=2), 1e-8)
    lo = np.full(T,np.nan); hi = np.full(T,np.nan); flag = np.zeros(T,bool)
    for i in range(WARM, T):
        f = l + tr + (S[i % P] if S is not None else 0.)
        sd = max(np.sqrt(max(v2, .5*vL)), vmin)
        a_, b_ = f-k*sd, f+k*sd
        lo[i], hi[i] = (np.exp(a_), np.exp(b_)) if log else (a_, b_)
        if floor is not None: lo[i] = max(lo[i], floor)
        flag[i] = (z[i] < a_) or (z[i] > b_)
        zi = float(np.clip(z[i], a_, b_)); e = zi - f
        v1 = (1-a1)*v1 + a1*e*e; v2 = (1-a2)*v2 + a2*v1; vL = .99*vL + .01*e*e
        if S is not None:
            ln = alpha*(zi - S[i % P]) + (1-alpha)*(l+tr); S[i % P] = gamma*(zi-ln) + (1-gamma)*S[i % P]
        else:
            ln = alpha*zi + (1-alpha)*(l+tr)
        if beta is not None: tr = beta*(ln-l) + (1-beta)*tr
        l = ln
    return lo, hi, flag

# ---------------- the metrics ----------------------------------------- #
cyc  = wave(12, [(1,1.,0.), (2,.44,.9), (3,.22,2.1)])
def A(i, note, set=None, mul=None, s=None):
    return dict(i=i, note=note, set=set, mul=mul, s=s)
def L(name, unit, shape, series, an, **kw):
    return dict(name=name, unit=unit, shape=shape, series=series, an=an, **kw)

M = []
M.append(L('Row count', 'trades', 'trend + rhythm',
  [dict(v=46_000*np.exp(.0040*td)*(1+.06*cyc) + wob(.32,620,.6,27,.35),
        cfg=dict(alpha=.20,beta=.05,gamma=.20,P=12,k=3.2,log=True), floor=0)],
  [A(19,"One region's feed never arrived",mul=.62), A(45,'Loader replayed the batch',mul=1.52)]))

M.append(L('File size', 'MB', 'random walk',
  [dict(v=182 + rwalk(1.15) + wob(.25,1.15,.5,29,.1),
        cfg=dict(alpha=.28,beta=.10,k=4.0), floor=0)],
  [A(38,'Export truncated mid-write',mul=.55)]))

M.append(L('Arrival time', 'minutes past midnight', 'two upstream schedules',
  [dict(v=bimodal(126, 174, .28) + wob(.2,4.5,.4,23,.5), cfg=dict(alpha=.30,k=2.6), floor=0)],
  [A(41,'Upstream job ran four hours late',set=392)]))

M.append(L('Min value  ·  quantity', 'units', 'pinned at a floor',
  [dict(v=105 + np.abs(wob(.3,26,.55,25,.2)), cfg=dict(alpha=.18,k=3.2))],
  [A(33,'Sells now arrive as negative quantities',set=-260)]))

M.append(L('Max value  ·  quantity', 'units', 'heavy tailed', 
  [dict(v=np.exp(11.42 + .20*rng.standard_normal(T) + .06*wob(.4,1,.5,24)),
        cfg=dict(alpha=.16,k=3.4,log=True), floor=1)],
  [A(47,'Nine-digit fat finger',set=9.4e8)], ylog=True))

M.append(L('Mean & median  ·  fees', 'GBP', 'a pair that should move together',
  [dict(v=84 + 5.5*cyc + wob(.3,1.5,.5,26,.15), cfg=dict(alpha=.20,gamma=.20,P=12,k=3.6), nm='Mean'),
   dict(v=79 + 5.0*cyc + wob(.3,1.3,.5,26,.6), cfg=dict(alpha=.20,gamma=.20,P=12,k=3.6), nm='Median')],
  [A(26,'A handful of very large trades',mul=1.30,s=0), A(49,'Wrong fee schedule deployed',mul=.83)]))

M.append(L('Standard deviation  ·  risk_score', 'points', 'volatility clustering',
  [dict(v=14.5 + wob(.45,1.45,.75,19,.3), cfg=dict(alpha=.20,k=3.7), floor=0)],
  [A(44,'Risk model redeployed with clamped scores',set=2.1)]))

M.append(L('Null rate  ·  isin', '%', 'trend down',
  [dict(v=.85 + 2.3*np.exp(-.0060*td) + wob(.3,.05,.55,25,.6),
        cfg=dict(alpha=.20,beta=.05,k=3.3,log=True), floor=0)],
  [A(40,'ISIN stopped populating for one venue',set=4.4)]))

M.append(L('Distinct values  ·  asset_class', 'categories', 'integer staircase',
  [dict(v=stair([(0,6),(T0+26,7)]), cfg=dict(alpha=.22,k=3.6,vmin=.22))],
  [A(27,'New asset class onboarded, then accepted'), A(50,'Two asset classes stopped arriving',set=3)]))

M.append(L('Uniqueness  ·  trade_ref', '%', 'pinned at a ceiling',
  [dict(v=100 - np.abs(wob(.2,.020,.55,21,.4)), cfg=dict(alpha=.18,k=3.9))],
  [A(36,'Batch loaded twice',set=61.2)]))

M.append(L('Min / max date  ·  settlement_date', 'days of history', 'sawtooth',
  [dict(v=sawtooth(15, 16, 96, jit=.012), cfg=dict(alpha=.30,gamma=.45,P=15,k=3.8,log=True), floor=1)],
  [A(39,'A 2019 backfill landed in today’s partition',set=2190)], ylog=True))

M.append(L('Subset count  ·  status = CANCELLED', 'trades', 'pulse train',
  [dict(v=pulses(10, 340, 1750) + wob(.3,26,.5,22,.3), cfg=dict(alpha=.22,gamma=.35,P=10,k=3.2), floor=0)],
  [A(44,'Venue started rejecting orders',set=1980)]))

M.append(L('Format compliance  ·  trader_lei', '%', 'ceiling with rare dips',
  [dict(v=99.72 - np.abs(wob(.25,.10,.6,24,.15)), cfg=dict(alpha=.18,k=3.3))],
  [A(34,'LEIs arrived padded with spaces',set=88.5)]))

M.append(L('Pair consistency  ·  currency = settlement_ccy', '%', 'slow erosion',
  [dict(v=99.90 - .0075*np.maximum(td,0) - np.abs(wob(.25,.027,.5,27,.7)),
        cfg=dict(alpha=.22,beta=.06,k=4.0))],
  [A(46,'New venue defaulted to the wrong settlement currency',set=93.8)]))

M.append(L('Equation breaks  ·  notional vs qty × price', 'per million rows', 'sparse counts',
  [dict(v=1.6 + np.abs(wob(.25,1.5,.7,20,.2)), cfg=dict(alpha=.18,k=3.4,log=True), floor=.05)],
  [A(31,'Price feed switched from dollars to cents',set=940)], ylog=True))

M.append(L('Temporal order violations', 'per million rows', 'near zero with bursts',
  [dict(v=2.4 + np.abs(wob(.3,2.2,.8,18,.55)), cfg=dict(alpha=.18,k=3.4,log=True), floor=.05)],
  [A(43,'Clock change made settlement precede trade',set=610)], ylog=True))

M.append(L('Correlation  ·  notional vs risk_score', 'coefficient', 'mean reverting',
  [dict(v=ou(.72,.14,.019), cfg=dict(alpha=.22,k=3.7))],
  [A(42,'Risk scores joined to the wrong trades',set=.08)]))

# ---------------- rendering ------------------------------------------- #
SLIDE = dict(figsize=(10.0, 5.4), dpi=200, title=15, label=11.5, tick=10.5,
             note=10.0, leg=10.0, lw=1.6, ms=3.4, dot=95)
GRID  = dict(figsize=(5.4, 3.55), dpi=140, title=10.5, label=8.5, tick=8,
             note=7.2, leg=7.5, lw=1.15, ms=2.1, dot=46)

def score(m):
    """Inject the anomalies and run the band engine. Returns per-series results."""
    out = []
    for si, s in enumerate(m['series']):
        v = s['v'].copy()
        for a in m['an']:
            if a['s'] is not None and a['s'] != si:
                continue
            g = T0 + a['i'] - 1
            if a['set'] is not None:
                v[g] = a['set']
            elif a['mul'] is not None:
                v[g] = v[g] * a['mul']
        lo, hi, br = engine(v, floor=s.get('floor'), **s['cfg'])
        vy, ly, hy, by = v[EX], lo[EX].copy(), hi[EX].copy(), br[EX].copy()
        ly[:WARM] = np.nan
        hy[:WARM] = np.nan          # the model has no opinion during warm-up
        by[:WARM] = False           # so it raises no alerts either
        out.append(dict(v=vy, lo=ly, hi=hy, flag=by, nm=s.get('nm', 'Actual')))
    return out

def render(m, ax, st):
    res = score(m)
    pens = [(INK, BAND), (INK2, BAND2)]
    for si, r in enumerate(res):
        ink, bnd = pens[si]
        ax.fill_between(x, r['lo'], r['hi'], color=bnd, alpha=.22, lw=0,
                        label='Expected range' if si == 0 else None)
        ax.plot(x, r['v'], color=ink, lw=st['lw'], marker='o', ms=st['ms'], label=r['nm'])
        ax.scatter(x[r['flag']], r['v'][r['flag']], s=st['dot'], color=ALERT, zorder=6,
                   edgecolor='white', lw=1.0, label='Flagged' if si == 0 else None)
    ax.axvspan(.5, WARM + .5, color='#eeeef1', zorder=0)
    ax.text(1.2, .04, 'warm-up', transform=ax.get_xaxis_transform(),
            fontsize=st['note'] - .4, color=MUTED, va='bottom')
    if m.get('ylog'):
        ax.set_yscale('log')
    ax.set_title(f"{m['name']}   ({m['unit']})", loc='left', fontsize=st['title'], fontweight='bold')
    ax.set_xlabel('Dataset refresh #', fontsize=st['label'])
    ax.tick_params(labelsize=st['tick'])
    ax.set_xlim(.5, N + .5)
    if not m.get('ylog'):
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(
            lambda q, p: f'{q:,.0f}' if abs(q) >= 1000 else f'{q:,.2f}'.rstrip('0').rstrip('.')))
        yl = ax.get_ylim()
        ax.set_ylim(yl[0] - (yl[1] - yl[0]) * .06, yl[1] + (yl[1] - yl[0]) * .30)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    base = res[0]['v']
    for a in m['an']:
        j = a['i']
        yv = res[a['s'] or 0]['v'][j - 1]
        left = j < N * .55
        ax.annotate(a['note'], xy=(j, yv),
                    xytext=(14 if left else -14, 40 if yv < np.median(base) else -40),
                    textcoords='offset points', fontsize=st['note'], color=ALERT,
                    ha='left' if left else 'right', va='center',
                    bbox=dict(boxstyle='round,pad=.32', fc='white', ec=ALERT, alpha=.95, lw=.8),
                    arrowprops=dict(arrowstyle='->', color=ALERT, lw=1.1))
    ax.legend(loc='upper left', frameon=True, framealpha=.93, ncol=3,
              fontsize=st['leg'], handletextpad=.4, columnspacing=.9)
    ax.text(.995, .02, m['shape'], transform=ax.transAxes, ha='right', va='bottom',
            fontsize=st['note'] - .2, color=MUTED, style='italic')
    return res

# ---------------- write one PNG per metric ---------------------------- #
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'metric_plots')
os.makedirs(OUT, exist_ok=True)

def slug(s):
    s = s.split('·')[0] if '·' in s else s
    return re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')

for i, m in enumerate(M, 1):
    fig, ax = plt.subplots(figsize=SLIDE['figsize'])
    render(m, ax, SLIDE)
    plt.tight_layout()
    fig.savefig(f'{OUT}/{i:02d}_{slug(m["name"])}.png', dpi=SLIDE['dpi'],
                bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f'{i:02d}  {m["name"]:46s} {m["shape"]}')

for tag, sl in [('1', slice(0, 9)), ('2', slice(9, 17))]:
    items = M[sl]
    fig, axes = plt.subplots(3, 3, figsize=(16.2, 10.65))
    axf = np.atleast_1d(axes).ravel()
    for ax, m in zip(axf, items):
        render(m, ax, GRID)
    for ax in axf[len(items):]:
        ax.set_visible(False)
    plt.tight_layout()
    fig.savefig(f'{OUT}/../overview_sheet_{tag}.png', dpi=140,
                bbox_inches='tight', facecolor='white')
    plt.close(fig)

print(f'\n{len(M)} plots written to {OUT}')
