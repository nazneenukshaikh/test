# AI Toolkit (starter)

A small, shared set of files that make GitHub Copilot (and any other AI coding
assistant) give better answers in our repositories.

## Why this exists

Copilot is smart about Python in general, but it knows nothing about *our*
Python: our folder layout, our Azure setup, our rule that secrets never appear
in code. So every engineer ends up typing the same context into chat, over and
over, and getting slightly different results.

These files put that context in the repo once, so the assistant reads it
automatically.

## What's in here

| Folder | What it is | When the assistant reads it |
|---|---|---|
| `foundation/AGENTS.md` | House rules for a repo: stack, commands, standards | Every single request |
| `foundation/instructions/` | Narrower rules that apply only to matching files | When you touch a matching file |
| `foundation/prompts/` | Saved prompts for repetitive chores | When you invoke one by name |
| `skills/` | Deeper "how we do X" guides with templates | Only when the task is relevant |

The split matters. `AGENTS.md` is loaded constantly, so it stays short. Skills
can be long because they are only pulled in when needed.

## Fastest way to try it

1. Copy `foundation/AGENTS.md` into the root of one real repo.
2. Fill in the `<TODO>` markers - takes about 15 minutes.
3. Copy `skills/` into `.github/skills/` in that repo.
4. Ask Copilot Chat something you'd normally ask, and compare the answer to
   before.

See `ADOPTION.md` for how to roll this out properly.

## Status

Deliberately minimal. Custom agents, MCP connections, TypeScript rules and
automated testing of these files are all sensible next steps, but not here yet.
