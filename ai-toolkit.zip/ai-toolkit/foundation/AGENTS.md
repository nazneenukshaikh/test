# Repository guide for AI assistants

Fill in every `<TODO>` before using this file. Leave nothing guessed - a
confident wrong answer here gets repeated in every response.

Keep this file short. It is read on every request, so it should hold only what
is true across the whole repo. Detail belongs in a skill.

## What this repo does

<TODO: two or three sentences. What business capability does this serve, who
consumes it, and what happens if it stops working.>

## Stack

- Python 3.12
- Dependency and environment management: `uv`
- <TODO: add the main frameworks, e.g. FastAPI, PySpark, pandas>
- Cloud: Azure
- Repo: GitLab, CI via `.gitlab-ci.yml`

## Commands

<TODO: confirm each of these actually works in this repo before shipping.>

```bash
uv sync                  # install dependencies
uv run pytest            # run tests
uv run ruff check .      # lint
uv run ruff format .     # format
uv run mypy .            # type check
```

Run the lint, format, type check and tests before proposing a change is
finished. If a command fails, fix the cause rather than working around it.

## Layout

<TODO: list the top-level folders and one line on what each holds. Delete the
example below.>

```
src/            application code
tests/          tests, mirroring the src/ layout
```

## Conventions

- Type hints on everything public. `mypy` must pass.
- Format and lint with `ruff`; do not hand-format around it.
- Naming: `snake_case` for functions and variables, `PascalCase` for classes.
- Prefer small, pure functions. Push side effects to the edges.
- Every new behaviour arrives with a test.
- <TODO: add any naming or structural convention specific to this repo.>

## Security and data handling

These are firm. If a request seems to require breaking one, stop and say so
rather than finding a workaround.

- **Secrets never appear in code, config files, comments, tests, or commit
  history.** They come from Azure Key Vault at runtime.
- **Authenticate with managed identity.** Use `DefaultAzureCredential`. Do not
  introduce connection strings, account keys, or SAS tokens.
- **Never log sensitive data.** No customer identifiers, account numbers, card
  numbers, names, addresses, or full request bodies. Log identifiers that are
  safe to expose, and correlation IDs.
- **Never use real client data as test data.** Generate synthetic data.
- <TODO: link the internal data classification standard, and name which
  categories this repo is permitted to handle.>

## Do not

- Add a dependency without saying so explicitly and explaining why. In a
  regulated environment a new package is a procurement and risk question, not
  just a technical one.
- Loosen a type check, disable a lint rule, or add a broad `# type: ignore` to
  make an error go away. Say the code needs rethinking instead.
- Rewrite or reformat code unrelated to the task. Large diffs hide real changes
  from reviewers.
- Weaken or skip a test to make a build pass.
- Invent an internal library, endpoint, or table name. If you need one and
  cannot see it, ask.

## When you are unsure

Say so, and say what you would need to know. An honest "I can't see how
authentication is wired up here" is far more useful than a plausible guess that
a reviewer then has to catch.
