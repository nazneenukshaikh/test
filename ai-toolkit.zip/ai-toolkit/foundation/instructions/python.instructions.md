---
applyTo: "**/*.py"
description: Python conventions for this organisation
---

# Python conventions

## Style

- Python 3.12. Use modern syntax: `X | None` over `Optional[X]`, `list[str]`
  over `List[str]`, built-in generics throughout.
- Type hints on every function signature that anything else calls.
- `ruff` decides formatting and import order. Do not argue with it in code.
- Names describe intent, not type: `settlement_date`, not `date_var`.

## Errors

- Raise specific exceptions, not bare `Exception`.
- Never write a silent `except: pass`. If a failure is genuinely safe to ignore,
  catch the specific exception and log at debug level with a reason, so the next
  reader knows it was a decision rather than an oversight.
- Let unexpected errors surface. Swallowing them turns a clear failure into a
  silent wrong number, which in financial work is considerably worse.

## Logging

- Use the `logging` module with a module-level logger. Never `print()`.
- Structured, key-value style messages so they are searchable in Azure Monitor.
- Log identifiers, counts, durations and outcomes. Do not log payloads,
  credentials, or personal data.

## Configuration

- Read configuration from environment variables, validated once at startup so a
  misconfiguration fails immediately rather than at 3am under load.
- Secrets come from Key Vault via `DefaultAzureCredential`. Never a literal.

## Tests

- `pytest`. Test files mirror the source layout.
- Name tests for the behaviour, not the function: `test_rejects_future_dated_
  transaction` beats `test_validate`.
- Arrange, act, assert - with a blank line between the three.
- One reason to fail per test.
- Cover the boundaries and the unhappy path, not just the happy one. Zero,
  negative, empty, null, duplicate, and the moment a value crosses a threshold.
- Synthetic data only.

## Dependencies

- `uv` manages everything. No `pip install` into a shared environment.
- Prefer the standard library. Flag any new third-party package explicitly for
  human approval rather than quietly adding it.
