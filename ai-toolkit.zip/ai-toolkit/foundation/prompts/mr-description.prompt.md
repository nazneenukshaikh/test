---
mode: agent
description: Draft a merge request description from the actual diff
---

Read my changes and draft a merge request description. Base it strictly on the
diff - do not describe intentions the code does not support.

Use this structure:

```markdown
## What changed
Two or three sentences in plain language. What behaviour is different now.

## Why
The problem this solves. Link the ticket if you can find a reference.

## How to verify
Concrete steps a reviewer can follow to satisfy themselves it works.

## Risk and rollback
What could go wrong, what it touches, and how to undo it.

## Notes for the reviewer
Anything needing a decision, anything deliberately left out, anything you
weren't sure about.
```

Keep it tight. A reviewer reads this to decide where to spend attention, so an
honest note under "notes for the reviewer" is worth more than a polished summary.

Flag it explicitly if the diff contains anything I should look at again before
this goes out: a new dependency, a schema change, a permission change, or
anything touching data handling.
