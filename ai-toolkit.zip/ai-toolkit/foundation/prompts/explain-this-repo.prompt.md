---
mode: ask
description: Orient a newcomer in an unfamiliar repository
---

I am new to this repository. Walk me through it so I can make a small change
with confidence.

Cover, in this order:

1. **Purpose** - what this service or pipeline does, in plain language, and who
   depends on it.
2. **Entry points** - where execution actually begins. Name the files.
3. **The main path** - trace one typical request or one pipeline run from start
   to finish, naming the files it passes through in order.
4. **External dependencies** - what it talks to: databases, queues, storage,
   other services, third parties.
5. **Where I should be careful** - anything that looks fragile, unusually
   coupled, or important to get right. Say why.
6. **How to run it locally** - the actual commands, and what I need configured
   first.

Base this only on what is in the repository. Where the code does not tell you
something, say "not visible in the repo" rather than filling the gap with a
sensible-sounding assumption - I have no way to tell the difference yet, which
is exactly the problem.
