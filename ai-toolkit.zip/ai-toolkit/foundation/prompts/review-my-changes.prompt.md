---
mode: agent
description: Self-review a change before opening a merge request
---

Review my uncommitted changes as a senior engineer would, before I put them in
front of a human reviewer. Read `AGENTS.md` and the instruction files first, and
hold the change to those standards.

Check for:

- **Correctness** - does it do what it claims? Look hard at boundaries: empty
  input, zero, negative numbers, duplicates, nulls, and anything that crosses a
  threshold.
- **Security and data handling** - any secret, credential, connection string or
  key introduced? Anything sensitive reaching a log or an error message? Any real
  data used as test data?
- **Tests** - is the new behaviour actually covered, including the failure path?
  Would these tests fail if the logic were wrong?
- **Error handling** - are failures surfaced, or quietly swallowed?
- **Scope** - is anything in this diff unrelated to the task and better split
  out?
- **Clarity** - would someone unfamiliar with this understand it in six months?

Group your findings as **must fix**, **worth considering**, and **fine as is**.
Be specific and quote the line. Being direct is more useful to me than being
polite - a real reviewer will not soften it either.

If the change is genuinely sound, say so plainly rather than manufacturing
concerns to look thorough.
