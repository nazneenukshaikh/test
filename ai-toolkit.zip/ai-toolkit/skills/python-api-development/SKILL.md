---
name: python-api-development
description: How we build FastAPI services - layered structure, Pydantic validation, one standard error format, versioning, idempotency for money-moving operations, pagination, Entra ID auth, correlation IDs, and the testing ladder. Use this whenever the task involves a FastAPI app, adding or changing an endpoint, request or response models, API validation, error responses, authentication on an API, or writing tests for an API - even if the request does not mention FastAPI by name.
---

# Python API development

Our APIs are consumed by other teams and, in some cases, sit on the path of a
payment. A confusing error shape costs another team an afternoon; a
non-idempotent endpoint costs a customer real money. Consistency and safety
before cleverness.

## Structure

```
src/api/
├── main.py                 app creation, middleware, router registration
├── routers/<resource>.py   HTTP layer only: parse, call, return
├── schemas/<resource>.py   Pydantic request and response models
├── services/<resource>.py  business logic - no FastAPI imports here
├── repositories/           database access
└── dependencies.py         shared dependencies: auth, db session, config
```

The rule that carries the most weight: **routers contain no business logic, and
services contain no HTTP.** A service function should be callable from a
scheduled job with no rewriting. When logic leaks into the router it becomes
reachable only through an HTTP request, and it stops being testable in
isolation.

## Request and response models

- Every request body and every response is a Pydantic model. Never a bare
  `dict`, never an untyped return.
- Separate models per direction. A `TransferRequest` and a `TransferResponse`
  are different shapes and will diverge; sharing one model forces awkward
  optional fields within a release or two.
- Never return the database model directly. It leaks internal columns, and any
  new column silently becomes part of the public contract.
- Validate at the boundary, and validate tightly: constrain string lengths, set
  numeric bounds, use enums for fixed sets. Rejecting a bad request at the edge
  is cheap; discovering it three services later is not.
- Money uses `Decimal` with an explicit currency field. Never `float`, and never
  an amount without a currency.

## One error format

Every error from every endpoint uses the same shape. Consumers write their
handling once.

```json
{
  "error": {
    "code": "INSUFFICIENT_FUNDS",
    "message": "Human readable, safe to show a user.",
    "correlation_id": "01JG7X..."
  }
}
```

- `code` is a stable machine-readable string. Clients branch on this, so treat
  changing one as a breaking change.
- `message` never contains a stack trace, a SQL fragment, an internal hostname,
  or personal data. Assume it may be displayed or logged by the caller.
- Always include the correlation ID, so a support conversation can be tied to a
  log entry without guesswork.

Status codes: 400 malformed, 401 not authenticated, 403 authenticated but not
permitted, 404 absent, 409 conflicts with current state, 422 failed validation,
429 rate limited, 500 our fault. Never return 200 with an error inside.

## Versioning

Version in the path: `/v1/transfers`. Cheap to add now, painful to retrofit.

Additive changes go in place. Removing a field, renaming one, tightening
validation, or changing an error code is breaking and needs a new version with
the old one running alongside.

## Idempotency

Any endpoint that creates something or moves money accepts an
`Idempotency-Key` header. Networks time out, clients retry, and a retried
transfer must not become two transfers.

Store the key with the result of the first successful request. On a repeat,
return the stored result rather than doing the work again. Scope keys to the
caller and expire them after a defined window. <TODO: agree the window and the
store - Redis or a table.>

## Lists

Never return an unbounded list. Today's thousand rows become next year's
million, and the failure arrives as a timeout in production.

Paginate every collection with a default page size and a hard maximum. Prefer
cursor-based pagination for anything large or actively changing, since offsets
skip and repeat rows when the underlying data shifts between pages.

## Auth and identity

- Authenticate with Entra ID; validate the JWT signature, issuer, audience and
  expiry on every request. <TODO: confirm the tenant, audience and whether we
  validate in-process or at the gateway.>
- Authorise separately from authenticating. Knowing who someone is does not
  establish what they may do.
- Check authorisation in the service layer, not only the router, so a second
  caller cannot reach it by another route.
- Secrets and signing configuration come from Key Vault via
  `DefaultAzureCredential`.

## Logging

- Generate a correlation ID for every request in middleware, return it in the
  response headers, and attach it to every log line for that request.
- Log method, path, status, duration and the caller's identifier.
- **Never log request or response bodies, headers, or tokens.** In a payments
  API the body is the sensitive part, and a well-meant debug log is the most
  common way sensitive data ends up somewhere it should not be.

## Async

FastAPI is async. A blocking call inside an `async def` stalls the whole event
loop, which shows up as unexplained latency across unrelated endpoints - a
genuinely difficult thing to diagnose after the fact.

Use async database drivers and async HTTP clients. If a blocking library is
unavoidable, run it in a thread pool rather than calling it directly.

## Testing

Three levels, cheapest first:

1. **Service tests** - business logic called directly, dependencies faked. The
   bulk of the tests live here. Fast, and they survive refactoring of the HTTP
   layer.
2. **API tests** - FastAPI's `TestClient` against the endpoint, with services
   overridden through dependency injection. Confirms status codes, validation,
   error shape and auth behaviour.
3. **Integration tests** - a real database, the smallest number that gives
   confidence.

Always test: the happy path, each validation failure, unauthenticated,
authenticated-but-forbidden, absent resource, and - for anything with an
idempotency key - the same request sent twice producing one effect.

## Reference

- `references/patterns.md` - worked code examples of the patterns above.
