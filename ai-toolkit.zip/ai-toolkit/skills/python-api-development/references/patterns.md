# Worked patterns

Illustrative, not copy-paste. `<TODO>` marks decisions still open.

## Layer separation

```python
# routers/transfers.py - HTTP only
@router.post("/v1/transfers", response_model=TransferResponse, status_code=201)
async def create_transfer(
    request: TransferRequest,
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")],
    caller: Annotated[Caller, Depends(current_caller)],
    service: Annotated[TransferService, Depends(get_transfer_service)],
) -> TransferResponse:
    result = await service.create(request, caller=caller, key=idempotency_key)
    return TransferResponse.model_validate(result)
```

The router parses, delegates, and returns. Nothing else. The service below knows
nothing about HTTP, so a batch job can call it unchanged.

## Request model with real constraints

```python
from decimal import Decimal
from typing import Annotated
from pydantic import BaseModel, Field, StringConstraints

AccountId = Annotated[str, StringConstraints(min_length=8, max_length=34)]


class TransferRequest(BaseModel):
    model_config = {"extra": "forbid"}   # unknown fields are rejected, not ignored

    from_account: AccountId
    to_account: AccountId
    amount: Decimal = Field(gt=0, decimal_places=2, max_digits=18)
    currency: Annotated[str, StringConstraints(min_length=3, max_length=3)]
    reference: Annotated[str, StringConstraints(max_length=140)] | None = None
```

`extra: forbid` matters more than it looks. Without it, a client misspelling a
field name gets a silent success with the field ignored.

## Consistent errors

```python
class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        self.status, self.code, self.message = status, code, message


@app.exception_handler(ApiError)
async def handle_api_error(request: Request, exc: ApiError) -> JSONResponse:
    correlation_id = request.state.correlation_id
    logger.warning("api_error code=%s status=%s correlation_id=%s",
                   exc.code, exc.status, correlation_id)
    return JSONResponse(
        status_code=exc.status,
        content={"error": {"code": exc.code,
                           "message": exc.message,
                           "correlation_id": correlation_id}},
    )


@app.exception_handler(Exception)
async def handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
    # Log the detail; return nothing revealing.
    logger.exception("unhandled correlation_id=%s", request.state.correlation_id)
    return JSONResponse(
        status_code=500,
        content={"error": {"code": "INTERNAL_ERROR",
                           "message": "An unexpected error occurred.",
                           "correlation_id": request.state.correlation_id}},
    )
```

Override FastAPI's default validation handler too, so 422s match the same shape.

## Correlation ID middleware

```python
@app.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    correlation_id = request.headers.get("X-Correlation-ID") or str(uuid4())
    request.state.correlation_id = correlation_id
    response = await call_next(request)
    response.headers["X-Correlation-ID"] = correlation_id
    return response
```

Honouring an inbound ID lets a trace span several services.

## Idempotency

```python
async def create(self, request, *, caller, key: str):
    if existing := await self.idempotency.get(caller.id, key):
        return existing                      # replay, do no work

    result = await self._perform_transfer(request)
    await self.idempotency.put(caller.id, key, result, ttl=<TODO>)
    return result
```

Store the key and the result together, and store it before returning, so a
client that retries after a timeout gets the same answer.

## Cursor pagination

```python
class Page(BaseModel):
    items: list[TransferResponse]
    next_cursor: str | None = None


@router.get("/v1/transfers", response_model=Page)
async def list_transfers(
    limit: Annotated[int, Query(ge=1, le=100)] = 25,   # bounded, always
    cursor: str | None = None,
    ...
): ...
```

## API test

```python
def test_rejects_negative_amount(client, valid_headers):
    response = client.post("/v1/transfers", headers=valid_headers, json={
        "from_account": "GB00TEST0001",
        "to_account": "GB00TEST0002",
        "amount": "-5.00",
        "currency": "GBP",
    })

    assert response.status_code == 422
    assert response.json()["error"]["code"]            # error shape holds
    assert "correlation_id" in response.json()["error"]


def test_same_idempotency_key_transfers_once(client, valid_headers):
    payload = {...}
    first = client.post("/v1/transfers", headers=valid_headers, json=payload)
    second = client.post("/v1/transfers", headers=valid_headers, json=payload)

    assert first.json()["id"] == second.json()["id"]   # one transfer, not two
```

All account identifiers here are synthetic. Never a real one.
