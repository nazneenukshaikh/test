---
name: python-data-engineering
description: How we build Python data pipelines on Azure with Spark and pandas - project layout, safe re-runs, incremental loads, schema handling, data quality checks, sensitive data rules, and pipeline testing. Use this whenever the task involves a data pipeline, ingestion, ETL or ELT, a Spark or PySpark job, a pandas transformation, reading or writing files in Azure storage, a data quality check, or backfilling and reprocessing data - even if the request does not use the word "pipeline".
---

# Python data engineering

Our pipelines move regulated financial data. That changes the priorities: a
pipeline that is slightly slow is an annoyance, a pipeline that silently
produces a wrong number is a serious incident. Optimise for correctness,
traceability and safe re-runs first.

<TODO: name the orchestrator used here - Databricks Jobs, Airflow, Azure Data
Factory - and how a job is triggered and scheduled.>

## Structure

Keep the three stages separate. It is the difference between a pipeline you can
test and one you can only run.

```
src/pipelines/<pipeline_name>/
├── extract.py      reading from the source, and nothing else
├── transform.py    pure functions: data in, data out, no I/O
├── load.py         writing to the target
└── job.py          wires the three together, handles config and logging
```

Transform functions take a DataFrame and return a DataFrame. No reading, no
writing, no clock, no credentials. This is what makes them testable without
standing up any infrastructure, and it is the single biggest quality win
available in pipeline code.

## Spark or pandas

Choose deliberately and say why in a comment.

- **pandas** - data fits comfortably in memory on one machine. Simpler, faster to
  develop, easier to debug.
- **Spark** - data does not fit, or already lives in a distributed store.

Do not use Spark for a 50MB file because the last job used Spark. Do not use
pandas for something that will grow past memory next quarter.

## Re-runnability

Assume every pipeline will be re-run: a source arrived late, a transformation was
wrong, an upstream system was restated. If re-running produces duplicates or
double-counts, the pipeline is not finished.

Make each run idempotent - running it twice leaves the same result as running it
once:

- Write with `overwrite` scoped to the partition being processed, not `append`
  into a shared location.
- Where append is unavoidable, deduplicate on a stable business key plus a
  version or timestamp, taking the latest.
- Derive the partition from the data's business date, not from today's date. A
  pipeline keyed to "now" cannot be replayed correctly.

## Incremental loads

Full reloads are simpler and correct; prefer them until volume makes them
impractical.

For incremental loads, use a high-water mark - the maximum value of a monotonic
column (an updated timestamp or a sequence number) from the last successful run,
persisted somewhere durable rather than inferred.

Two traps worth knowing about, because both produce silent gaps rather than
errors:

- **Late-arriving records.** A row timestamped before your high-water mark can
  land after you have moved past it. Overlap the window by a safe margin and rely
  on idempotent writes to absorb the repeats.
- **Hard deletes at source.** A high-water mark cannot see a row that no longer
  exists. Either the source provides soft deletes or change data capture, or you
  need a periodic full reconciliation. Say explicitly which applies.

## Schemas

- **Always declare the schema explicitly** when reading. Inferred schemas change
  silently when the data changes, and a column that quietly becomes a string
  breaks arithmetic downstream without raising anything.
- **Use exact types for money.** `Decimal` in pandas, `DecimalType` in Spark.
  Never `float` for a monetary amount - binary floating point cannot represent
  0.01 exactly, and the error accumulates across millions of rows.
- **Fail on unexpected columns or types.** A source that changed shape is news,
  not something to accommodate quietly.
- Store dates as dates and timestamps as UTC timestamps, never as strings.

## Data quality checks

Every pipeline validates before it writes. A failed check should stop the run,
not warn into a log nobody reads.

Baseline checks worth having everywhere:

- **Row count** within an expected range, and compared to the previous run. A
  sudden drop to a tenth of yesterday's volume is the most common symptom of a
  broken upstream feed.
- **Not null** on every key and every column something downstream relies on.
- **Uniqueness** of the business key.
- **Referential integrity** against reference data where it applies.
- **Reconciliation totals** - sum the amount column and compare to the source's
  own control total. This is the check that actually catches wrong numbers.

Record the results of every check with the run, so that when someone asks in
three months whether a figure was validated, there is an answer.

## Sensitive data

- Read from and write to Azure storage using `DefaultAzureCredential` and managed
  identity. No account keys, no SAS tokens, no connection strings.
- **Never log data.** Log row counts, durations, partition names and outcomes.
  Never a DataFrame, never a sample row, never a failed record's contents - a
  `df.show()` left in a job puts customer data into a log store where it should
  not be, and removing it afterwards is not straightforward.
- When a record fails validation, log its business key and the rule it broke.
  Route the record itself to a controlled quarantine location, not to the log.
- **Test data is synthetic.** Never a copy of production, not even redacted, not
  even briefly.

## Testing

Test the transforms as ordinary functions with small hand-built DataFrames - ten
rows chosen to cover the interesting cases beats a thousand random ones. Cover
nulls, duplicates, zero and negative amounts, boundary dates, and the empty
input.

Test the quality checks too: build data that should fail each rule and assert
that it does. An untested validation rule is often an inactive one.

For extract and load, test the small amount of real logic - the path being
built, the partition being chosen - and mock the storage client.

## Reference

- `references/patterns.md` - worked code examples of the patterns above.

<TODO: add a reference file with our actual storage paths, naming conventions
and orchestrator idioms once the pilot repo settles them.>
