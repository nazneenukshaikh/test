# Worked patterns

Illustrative, not copy-paste. Adapt to the repo. `<TODO>` marks anything that
depends on decisions we have not made yet.

## Authentication

```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

credential = DefaultAzureCredential()

# Secrets from Key Vault, never from code or config files.
secrets = SecretClient(vault_url="<TODO: vault url>", credential=credential)
api_token = secrets.get_secret("<TODO: secret name>").value
```

For Spark reading from ADLS, prefer the cluster's managed identity over passing
credentials in the job. <TODO: confirm how identity is attached to our clusters.>

## A pure transform

```python
import pandas as pd


def normalise_transactions(df: pd.DataFrame) -> pd.DataFrame:
    """Standardise incoming transactions. No I/O, so this is trivially testable."""
    out = df.copy()
    out["amount"] = out["amount"].astype("string").map(Decimal)
    out["booked_at"] = pd.to_datetime(out["booked_at"], utc=True, errors="raise")
    out = out.dropna(subset=["transaction_id", "account_id", "amount"])
    return out.drop_duplicates(subset=["transaction_id"], keep="last")
```

Note `errors="raise"`. The default coerces bad dates to null, which turns a
data problem into a silent one.

## Explicit schema on read

```python
from pyspark.sql.types import (
    DecimalType, StringType, StructField, StructType, TimestampType,
)

TRANSACTION_SCHEMA = StructType([
    StructField("transaction_id", StringType(), nullable=False),
    StructField("account_id", StringType(), nullable=False),
    StructField("amount", DecimalType(18, 2), nullable=False),
    StructField("booked_at", TimestampType(), nullable=False),
])

df = (
    spark.read
    .schema(TRANSACTION_SCHEMA)      # never inferSchema
    .option("mode", "FAILFAST")      # a malformed row stops the run
    .json(source_path)
)
```

## Idempotent partition write

```python
(
    df.write
    .mode("overwrite")                       # replaces only this partition
    .option("partitionOverwriteMode", "dynamic")
    .partitionBy("business_date")
    .format("delta")                         # <TODO: confirm our table format
    .save(target_path)
)
```

Re-running for the same `business_date` replaces that day's data rather than
duplicating it.

## Quality check that stops the run

```python
class DataQualityError(Exception):
    """Raised when validated data fails a rule. Never suppress this."""


def check_reconciles(df, source_total: Decimal, tolerance: Decimal) -> None:
    actual = df.agg({"amount": "sum"}).collect()[0][0]
    difference = abs(actual - source_total)
    if difference > tolerance:
        # Log the discrepancy, not the data.
        raise DataQualityError(
            f"reconciliation failed: difference={difference} tolerance={tolerance}"
        )
    logger.info("reconciliation passed difference=%s", difference)
```

## Testing a transform

```python
def test_drops_rows_missing_an_account():
    df = pd.DataFrame({
        "transaction_id": ["t1", "t2"],
        "account_id": ["a1", None],
        "amount": ["10.00", "20.00"],
        "booked_at": ["2026-01-01T00:00:00Z"] * 2,
    })

    result = normalise_transactions(df)

    assert result["transaction_id"].tolist() == ["t1"]


def test_keeps_latest_of_duplicate_transaction_ids():
    ...
```

Ten deliberate rows beat a thousand random ones, because you know what each row
is there to prove.
