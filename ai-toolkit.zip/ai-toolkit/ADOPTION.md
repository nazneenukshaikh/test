# Adoption guide

## Step 1: Pilot on one repo (2 weeks)

Pick one active Python repo and two or three engineers who are already using
Copilot daily. Copy the files in, fill the `<TODO>` markers, and let them work
normally.

The point of the pilot is not to prove the files are good. It is to find out
what the engineers *change*, because those changes are the real standards.

Worth capturing before and after, even informally:

- Do reviewers leave fewer "you forgot our error format" style comments?
- Does a new joiner get productive faster?
- How often does the assistant still need to be corrected on basics?

## Step 2: Where the files live

Two placements, and they do different jobs.

**Per repo** - `AGENTS.md` at the root, plus `.github/instructions/`,
`.github/prompts/` and `.github/skills/`. Repo-specific, version controlled,
reviewed like code.

**Per engineer** - skills also work from a personal folder in the home
directory, which means they apply across every repo without touching any of
them. Useful for our general Python and Azure conventions.

## Step 3: Distribution

Hand-copying files into 40 repos does not scale, and copies drift apart within a
month.

- **Central repo**: this repo becomes the single source of truth. Changes go
  through merge request, so standards are debated in the open.
- **Sync job**: a small GitLab CI job in each product repo pulls the shared
  files from a pinned tag. Teams get updates without hand-copying, and pinning
  means an update never lands unannounced mid-sprint.
- **DevPod image**: bake the personal-level skills into the devcontainer so a
  new engineer gets the toolkit on day one with zero setup. This is the single
  highest-leverage distribution step and worth doing early.

## Step 4: Guardrails

Non-negotiables for us, worth stating explicitly rather than assuming:

- **No client data in prompts.** Not in a chat window, not in a test fixture,
  not "just this once to debug". Use synthetic data.
- **AI-generated code is reviewed like any other code.** Same pipeline, same
  quality gates, same reviewer. No exceptions and no fast lane.
- **These files are code.** Merge request, review, version tag. A wrong rule in
  `AGENTS.md` gets silently applied across every repo that reads it, which is
  exactly why it needs the same scrutiny as a shared library.
- **Treat outside skills as supply chain.** GitHub warns that community skills
  are unverified and can contain hidden instructions or malicious scripts.
  Read anything before adopting it. Prefer writing our own.

## Step 5: Keeping it alive

Give the repo a named owner and review it quarterly. An instructions file that
describes last year's architecture is worse than no file, because engineers stop
trusting the whole toolkit after being misled once.

Add to it when a review comment repeats. If three reviewers say the same thing
in a month, that thing belongs in a file.
